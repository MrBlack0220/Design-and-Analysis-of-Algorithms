'''
Author: SunnyNie
Date: 2022-08-25
Description: 算法-作业1
'''
def EuclidGCD(a,b):
    """
    欧几里得GCD算法求两个数的最大公因数

    Args:
        a (int): None
        b (int): None
    """
    print("a\tb\tr")
    while(b):
        r = a % b
        print(a,'\t',b,'\t',r) # 打印step1:计算余数结果
        a = b
        b = r
        print(a,'\t',b,'\t',r)  # 打印step2:更新a、b结果
    return a 



if __name__=='__main__':
    print('\n')	
    a,b=map(int,input("Please input two Integers:").split())
    EuclidGCD(a,b)